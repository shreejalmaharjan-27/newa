<?php
$array_one= array("अ","आ","इ","ई","उ","ऊ","ऋ","ऌ","ए","ऐ","ओ","औ","क","ख","ग","घ","ङ","ङ्ह","च","छ","ज","झ","ञ","ञ्ह","ट","ठ","ड","ढ","ण","त","थ","द","ध","न","प","फ","ब","भ","म","य","र","र्ह","ल","व","श","ष","स","ह","ा","ि","ी","ु","ू","ृ","े","ै","ो","ौ","्","ँ","ं","ः","़","ॐ","।","॥","०","१","२","३","४","५","६","७","८","९","‍","‌" );
$array_two = array("𑐀","𑐁","𑐂","𑐃","𑐄","𑐅","𑐆","𑐈","𑐊","𑐋","𑐌","𑐍","𑐎","𑐏","𑐐","𑐑","𑐒","𑐓","𑐔","𑐕","𑐖","𑐗","𑐘","𑐙","𑐚","𑐛","𑐜","𑐝","𑐞","𑐟","𑐠","𑐡","𑐢","𑐣","𑐥","𑐦","𑐧","𑐨","𑐩","𑐫","𑐬","𑐭","𑐮","𑐰","𑐱","𑐲","𑐳","𑐴","𑐵","𑐶","𑐷","𑐸","𑐹","𑐺","𑐾","𑐿","𑑀","𑑁","𑑂","𑑃","𑑄","𑑅","𑑆","𑑉","𑑋","𑑌","𑑐","𑑑","𑑒","𑑓","𑑔","𑑕","𑑖","𑑗","𑑘","𑑙","‍","‌" )  ;       
         
         $str = htmlspecialchars($_POST['legacy_text']);
$convstr=$str;
$c = count($array_two);
         for( $i = 0; $i<$c; $i++ ) {
           $convstr = str_replace( $array_one[$i], $array_two[$i],$convstr);
         }
      ?>
    



<!DOCTYPE html>
<html>
<head>
	<title>Nepal Lipi Conversion from Devanagari</title>


<script>
function myFunction() {
 /* Get the text field */
 var copyText = document.getElementById("unicode_text");

 /* Select the text field */
 copyText.select();

 /* Copy the text inside the text field */
 document.execCommand("copy");

 /* Alert the copied text */
//  alert("Copied the text: " + copyText.value);
}
</script>





	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="https://rafled.com/converter/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/css/util.css">
	<link rel="stylesheet" type="text/css" href="https://rafled.com/converter/css/main.css">
<!--===============================================================================================-->
<script data-ad-client="ca-pub-5111582965061906" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</head>
<body>
<script src="https://CDN.jsdelivr.net/npm/darkmode-js@1.5.5/lib/darkmode-js.min.js"></script>

<script>
new Darkmode().showWidget();

</script>
	<form name="Form1" method="post" >
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" name="Form1" method="post">
					<h1 class="login100-form-title p-b-26" style="font-family: NewaLipi;">
					𑐣𑐾𑐥𑐵𑐮 𑐮𑐶𑐥𑐶 𑐎𑐣𑑂𑐨𑐬𑐚𑐬
					</h1>
					<hr class="sep-2">
					<h3 class="login100-form-title p-b-26">
					Nepal Lipi Converter
					</h3>
				

					<div class="wrap-input100 validate-input" data-validate = "Valid email is: a@b.c">
						<h6 style="color:#5e5a5a;">Paste Devanagari Text Here</h6>
						<input class="input100" style="color:#1443ff; font-size: 25px; font-family: NewaLipi;" type="text" id="legacy_text"  name="legacy_text" value="<? echo $str?>">
						<span class="focus-input100" data-placeholder=""></span>
					</div>
					<div class="container-login100-form-btn">
					<div class="wrap-login100-form-btn">
					<div class="login100-form-bgbtn"></div>
					
<button class="login100-form-btn" type=submit accesskey="c" id="converter" name="converter">
								Convert
							</button>
							</div>
							</div>
							
							<br>
							<br>
					<div class="wrap-input100 validate-input" data-validate="Enter password">
						
						
						<h6 style="color:#5e5a5a;">Your Converted Nepal Lipi Text</h6>
						<input class="input100" style="color:#1443ff; font-size: 25px; font-family: NewaLipi;" type="text" name="password" id="unicode_text" name="ConvertedText" onClick="select_all();" value="<? echo $convstr?>">
						
						<span class="focus-input100" data-placeholder=""></span>
						
					</div>
					<div class="container-login100-form-btn">
					<div class="wrap-login100-form-btn">
					<div class="login100-form-bgbtn"></div>
					<button class="login100-form-btn"  onClick="myFunction()"> Copy Text</button>
					</div>
					</div>
					
				
					<br>
					<br>
<p>Want to install Newa Font on your device? Click <a href="https://rafled.com/newa.otf"><font color=blue>here</font></a> to Download.</p>
<br>
<br>
<p>
©2020, Shreejal Maharjan & Pawan Chitrakar
					</p>
						

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/bootstrap/js/popper.js"></script>
	<script src="https://rafled.com/converter/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/daterangepicker/moment.min.js"></script>
	<script src="https://rafled.com/converter/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="https://rafled.com/converter/js/main.js"></script>
</form>
</body>
</html>